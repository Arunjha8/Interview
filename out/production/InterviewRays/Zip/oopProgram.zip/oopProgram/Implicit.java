package com.oopProgram;

public class Implicit {

	public Implicit() {

		System.out.println("This is default constructor");
	}

}
