package com.oopProgram;

public interface Accountant {

	public static final String name = null ;

	public String add(String name);

}
