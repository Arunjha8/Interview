package com.oopProgram;

public interface Richman {

	public void donationg(int i);

}
