package com.oopProgram;

public class Course {
	public String name;
	
	public Course() {	
	}
	
	public Course(String name) {
		this.name=name;
	}

}
