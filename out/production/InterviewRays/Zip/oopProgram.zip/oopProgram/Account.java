package com.oopProgram;

public class Account {

	private double balance;

	public Account(double ammount) {
		this.balance = ammount;
	}

	public void deposite(double amt) {
		System.out.println("Total balance : " + balance);
		System.out.println("Deposite Amt : " + amt);
		balance += amt;
		System.out.println("Total Balance After Deposite : " + balance);
	}

	public void withdraw(double amt) {
		if(balance>2000) {
			System.out.println("Total balance : " + balance);
			System.out.println("withdraw Amt : " + amt);
		balance -= amt;
		System.out.println("Total Balance After withdraw : " + balance);
		}else {
			System.out.println("Insuficent balance");
		}
	}

	public static void main(String[] args) {
		Account a = new Account(1500.0);
		a.deposite(5.0);
		a.withdraw(500.0);
	}

}
