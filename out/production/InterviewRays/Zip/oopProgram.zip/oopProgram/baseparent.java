package com.oopProgram;

public class baseparent {

	public baseparent() {
		
	}
	public baseparent(String name) {
		
	}
	
	 
	
}
