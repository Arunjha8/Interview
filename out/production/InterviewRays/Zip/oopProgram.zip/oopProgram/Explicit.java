package com.oopProgram;

public class Explicit {

	public Explicit() {

		System.out.println("dtgfvb");

	}

}
