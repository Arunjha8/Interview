package com.oopProgram;

public class childclass extends baseparent{
	
	private String city;

	public childclass() {
		
	}
	
	public childclass(String name , String lastname) {
		super(name);
	}
	public childclass(String name,String lastname,String address) {
		
		this(name, lastname);
		
		System.out.println(name +" "+ lastname +" "+" "+address);


	}
}

