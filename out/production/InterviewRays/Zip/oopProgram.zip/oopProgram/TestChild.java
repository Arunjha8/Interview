package com.oopProgram;

public class TestChild {

	public static void main(String[] args) {
		
		childclass c = new childclass("ishika", "sahu", "indore");
		
	
	}
}
