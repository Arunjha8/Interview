package Basics;
@FunctionalInterface
public interface ArmsInterface {
public void arms(int a);
}
 

